<?php
$lang['viewsite']['module_name']  = 'view site link';
$lang['viewsite']['module_intro'] = 'Created to show the hooks to module developers. Adds a direct link to the site in the admin menu.';
$lang['viewsite']['message']      = 'view site';
?>