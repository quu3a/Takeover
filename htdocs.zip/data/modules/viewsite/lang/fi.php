<?php
$lang['viewsite']['module_name'] = 'katso sivustoasi';
$lang['viewsite']['module_intro'] = 'Tehty esitelläksemme uudet koukut (new hooks). Lisää suoran linkin sivustolle admin valikkoon.';
$lang['viewsite']['message'] = 'katso sivustoasi';
?>