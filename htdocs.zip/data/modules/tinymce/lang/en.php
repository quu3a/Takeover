<?php
$lang['tinymce']['module_name']  = 'tinymce';
$lang['tinymce']['module_intro'] = 'Adds the TinyMCE-editor to pluck. TinyMCE has been developed by <a href="http://tinymce.moxiecode.com/" target="_blank">Moxiecode</a>.';
?>