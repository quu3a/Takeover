<?php
$lang['contactform']['module_name'] = 'kontaktni obrazec';
$lang['contactform']['module_intro'] = 'z kontaktnim obrazcom, dovolite obiskovalcem da vam pošljejo sporočilo';
$lang['contactform']['fields'] = 'Niste pravilno vnesli vseh podatkov.';
$lang['contactform']['email_title'] = 'Sporočila od vaše spletne strani od';
$lang['contactform']['been_send'] = 'Vaše sporočilo je bilo uspešno poslano.';
$lang['contactform']['not_send'] = 'Vaše sporočilo ni mogli biti poslano, saj je prišlo do napake.';
?>