<?php
$lang['contactform']['module_name'] = 'kontakt form';
$lang['contactform']['module_intro'] = 'med en kontakt form, kan dine besøgede sende dig en meddelse';
$lang['contactform']['fields'] = 'Du udfyldte ikke alle felterne korrekt.';
$lang['contactform']['email_title'] = 'Besked fra din hjemmeside formular';
$lang['contactform']['been_send'] = 'Din besked er blevet sendt korrekt.';
$lang['contactform']['not_send'] = 'Din besked kunne ikke sendes grundet, at der opstod en fejl.';
?>