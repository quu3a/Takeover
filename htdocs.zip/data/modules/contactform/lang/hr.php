<?php
$lang['contactform']['module_name'] = 'kontaktt forma';
$lang['contactform']['module_intro'] = 'Sa kontakt formom,možete dozvolitu Vašim posjetiteljima da Vam pošalju poruku';
$lang['contactform']['fields'] = 'Niste popunili sva polja ispravno.';
$lang['contactform']['email_title'] = 'Poruka sa Vaše stranice od';
$lang['contactform']['been_send'] = 'Vaša je poruka uspješno poslana.';
$lang['contactform']['not_send'] = 'Poruka nije mogla biti poslana,pojavila se greška.';
?>