<?php
$lang['contactform']['module_name'] = 'contactformulier';
$lang['contactform']['module_intro'] = 'bezoekers kunnen een contactformulier gebruiken om u een berichtje te sturen';
$lang['contactform']['fields'] = 'U heeft niet alle velden correct ingevuld.';
$lang['contactform']['email_title'] = 'Bericht van uw website van';
$lang['contactform']['been_send'] = 'Uw bericht is met succes verzonden.';
$lang['contactform']['not_send'] = 'Door een onverwachte error kon uw bericht niet verzonden worden.';
?>