<?php
$lang['contactform']['module_name'] = 'contact form';
$lang['contactform']['module_intro'] = 'with a contact form, you can allow your visitors to send you a message';
$lang['contactform']['fields'] = 'Vous n\'avez pas rempli correctement tous les fichiers.';
$lang['contactform']['email_title'] = 'Message de votre site, de ';
$lang['contactform']['been_send'] = 'Votre message a été envoyé avec succès.';
$lang['contactform']['not_send'] = 'Votre message n\'a pas été envoyé, une erreur est survenue';
?>