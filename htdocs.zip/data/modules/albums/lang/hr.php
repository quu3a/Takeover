<?php
$lang['albums']['title'] = 'albumi';
$lang['albums']['descr'] = 'koristite albume kako bi ste pokazali Vašim posjetiteljima Vaše najomiljenije slike ';
$lang['albums']['message'] = 'Ovdje možete uređivati Vaše albume.Koristite albume kako bi ste pokazali Vašim posjetiteljima Vaše najomiljenije slike .Umetnite albume u Vašu stranicu odabirom "umetni album"prilikom uređivanja stranice.';
$lang['albums']['edit_albums'] = 'uredi album';
$lang['albums']['new_album'] = 'novi album';
$lang['albums']['choose_name'] = 'odaberi najprije ime za svoj novi album,zatim klikni "spremi"';
$lang['albums']['delete_album'] = 'izbriši album';
$lang['albums']['edit_album'] = 'uredi album';
$lang['albums']['album_message1'] = 'Koristi ovu stranicu za dodavanje i uređivanje albuma <b>JPG</b>-slike su podržane';
$lang['albums']['album_message2'] = 'uploadaj novu sliku ovdje.odaberi naziv i opis,kvalitetu u kojoj če biti prikazana.što veča kvaliteta to veča datoteka.';
$lang['albums']['edit_images'] = 'uredi sliku';
$lang['albums']['new_image'] = 'nova slika';
$lang['albums']['quality'] = 'kvaliteta (1-100)';
$lang['albums']['edit_image'] = 'uredi sliku';
$lang['albums']['doesnt_exist'] = 'Takav album ne postoji.';
$lang['albums']['name_exist'] = 'There is already an album with that name.';
$lang['albums']['image_exist'] = 'There is already an image with that name.';
$lang['albums']['change_order'] = 'promjeni redosljed slike';
$lang['albums']['already_top'] = 'Slika se več nalazi na vrhu, tako da se nemože izmjeniti.';
$lang['albums']['already_last'] = 'Slika se več nalazi na kraju, tako da se nemože izmjeniti.';
$lang['albums']['delete_image'] = 'obriši sliku';
$lang['albums']['image_width'] = 'The width in pixels the images will be resized to. Choose 0 to disable automatic resizing.';
$lang['albums']['thumb_width'] = 'The width in pixels the thumbnails will be resized to. Cannot be disabled.';
$lang['albums']['settings_error'] = 'The width of the resized images should be numeric.';
?>