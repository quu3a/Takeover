<?php
$sitetitle = 'Indian Cyber Security Solution';
$email = 'mquraishak@gmail.com';
?>