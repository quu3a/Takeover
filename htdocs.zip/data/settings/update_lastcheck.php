<?php
$lastcheck = '286';
$lastupdatestatus = '';
$pluck_version = ' 127.0.0.1';
?>